@echo off
setlocal
cd /d "%~dp0"
title VideoDownloader build

rem Find a real Python (skip the Microsoft Store stub)
set "PY="
py -3 -c "import sys" >nul 2>nul
if not errorlevel 1 set "PY=py -3"
if defined PY goto :have_python
python -c "import sys" >nul 2>nul
if not errorlevel 1 set "PY=python"
if defined PY goto :have_python

echo.
echo Python not found.
echo Install it from https://www.python.org/downloads/
echo During install, check the box "Add python.exe to PATH".
echo Then run build.bat again.
goto :fail

:have_python
if exist ".venv\Scripts\python.exe" goto :have_venv
echo Creating virtual environment...
%PY% -m venv .venv
if errorlevel 1 goto :fail

:have_venv
".venv\Scripts\python.exe" build.py
if errorlevel 1 goto :fail
echo.
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Read the messages above.
pause
exit /b 1
